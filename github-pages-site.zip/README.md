# GitHub Pages - Downloads Oficiais

Site simples para listar downloads oficiais com atualização automática via GitHub Actions.

Como usar: crie um repositório no GitHub, envie os arquivos deste pacote e ative GitHub Pages apontando para a pasta /docs na branch main.
